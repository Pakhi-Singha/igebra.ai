'use client';
import { ScatterChart, CartesianGrid, XAxis, YAxis, Tooltip, Scatter, ResponsiveContainer } from 'recharts';

export function ScatterAttentionVsScore({ data }:{ data:any[] }){
  return (
    <div style={{ width:'100%', height:320 }}>
      <ResponsiveContainer>
        <ScatterChart>
          <CartesianGrid />
          <XAxis dataKey="attention" name="Attention" />
          <YAxis dataKey="assessment_score" name="Score" />
          <Tooltip cursor={{ strokeDasharray: '3 3' }} />
          <Scatter data={data} />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}
