'use client';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export function BarSkillVsScore({ data, skill }:{ data:any[], skill:string }){
  const agg:any = {};
  data.forEach((d)=>{
    const bucket = Math.round(d[skill] / 10) * 10; // bucket by 10s
    if(!agg[bucket]) agg[bucket] = { bucket, avgScore:0, count:0 };
    agg[bucket].avgScore += d.assessment_score;
    agg[bucket].count += 1;
  });
  const rows = Object.values(agg).map((r:any)=>({ 
    bucket: r['bucket'], 
    avgScore: r['avgScore']/r['count']
  })).sort((a:any,b:any)=>a.bucket-b.bucket);

  return (
    <div style={{ width:'100%', height:320 }}>
      <ResponsiveContainer>
        <BarChart data={rows as any[]}>
          <XAxis dataKey="bucket" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="avgScore" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
