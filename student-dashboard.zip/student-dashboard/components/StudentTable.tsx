'use client';
import { useMemo, useState } from 'react';

export function StudentTable({ data, onSelect }:{ data:any[], onSelect:(s:any)=>void }){
  const [q, setQ] = useState('');
  const [sortKey, setSortKey] = useState('assessment_score');
  const [asc, setAsc] = useState(false);

  const filtered = useMemo(()=>{
    const lower = q.toLowerCase();
    return data.filter((d)=> 
      d.name.toLowerCase().includes(lower) ||
      d.student_id.toLowerCase().includes(lower) ||
      d.class.toLowerCase().includes(lower) ||
      (d.persona_name || '').toLowerCase().includes(lower)
    );
  }, [q, data]);

  const sorted = useMemo(()=>{
    const rows = [...filtered];
    rows.sort((a:any,b:any)=> {
      const va = a[sortKey];
      const vb = b[sortKey];
      if(typeof va === 'number' && typeof vb === 'number') {
        return asc ? va - vb : vb - va;
      }
      return asc ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
    });
    return rows;
  }, [filtered, sortKey, asc]);

  const th = (key:string, label:string)=>(
    <th onClick={()=>{ setAsc(k=> key===sortKey ? !k : false); setSortKey(key); }}
        style={{ cursor:'pointer', padding:'8px 6px', textAlign:'left', borderBottom:'1px solid #24305a' }}>
      {label} {sortKey===key ? (asc?'▲':'▼') : ''}
    </th>
  );

  return (
    <div>
      <input
        placeholder="Search by name/id/class/persona"
        value={q}
        onChange={e=>setQ(e.target.value)}
        style={{ width:'100%', padding:8, borderRadius:8, border:'1px solid #2c3a78', background:'#0f1430', color:'white', margin:'8px 0 12px' }}
      />
      <div style={{ overflowX:'auto' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ background:'#0f1430' }}>
              {th('student_id','ID')}
              {th('name','Name')}
              {th('class','Class')}
              {th('comprehension','Comp')}
              {th('attention','Attn')}
              {th('focus','Focus')}
              {th('retention','Retn')}
              {th('engagement_time','Eng (min)')}
              {th('assessment_score','Score')}
              {th('persona_name','Persona')}
            </tr>
          </thead>
          <tbody>
            {sorted.map((s:any)=>(
              <tr key={s.student_id} onClick={()=>onSelect(s)} style={{ borderBottom:'1px solid #24305a' }}>
                <td style={{ padding:6 }}>{s.student_id}</td>
                <td style={{ padding:6 }}>{s.name}</td>
                <td style={{ padding:6 }}>{s.class}</td>
                <td style={{ padding:6 }}>{s.comprehension}</td>
                <td style={{ padding:6 }}>{s.attention}</td>
                <td style={{ padding:6 }}>{s.focus}</td>
                <td style={{ padding:6 }}>{s.retention}</td>
                <td style={{ padding:6 }}>{s.engagement_time}</td>
                <td style={{ padding:6, fontWeight:700 }}>{s.assessment_score}</td>
                <td style={{ padding:6 }}>{s.persona_name || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
