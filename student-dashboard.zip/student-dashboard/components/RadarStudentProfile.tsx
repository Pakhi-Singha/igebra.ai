'use client';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';

export function RadarStudentProfile({ student }:{ student:any }){
  const rows = [
    { metric: 'Comprehension', value: student.comprehension },
    { metric: 'Attention', value: student.attention },
    { metric: 'Focus', value: student.focus },
    { metric: 'Retention', value: student.retention },
  ];
  return (
    <div style={{ width: '100%', height: 320 }}>
      <ResponsiveContainer>
        <RadarChart data={rows}>
          <PolarGrid />
          <PolarAngleAxis dataKey="metric" />
          <Radar dataKey="value" />
        </RadarChart>
      </ResponsiveContainer>
      <div style={{ marginTop: 8, fontSize: 12, opacity: 0.85 }}>
        <strong>{student.name}</strong> &middot; Score: {student.assessment_score} &middot; Class: {student.class}
      </div>
    </div>
  );
}
