export function Insights({ data }:{ data:any[] }){
  const n = data.length;
  const avg = (key:string)=> data.reduce((s,r)=> s + (r[key]||0), 0)/n;
  const pairs = [
    ['comprehension','assessment_score'],
    ['focus','assessment_score'],
    ['retention','assessment_score'],
    ['attention','assessment_score']
  ] as const;
  const corr = (a:string,b:string)=>{
    const ax = data.map(d=>d[a] as number);
    const bx = data.map(d=>d[b] as number);
    const meanA = avg(a);
    const meanB = avg(b);
    const num = ax.map((v,i)=>(v-meanA)*(bx[i]-meanB)).reduce((s,v)=>s+v,0);
    const den = Math.sqrt(ax.map(v=>Math.pow(v-meanA,2)).reduce((s,v)=>s+v,0)) * Math.sqrt(bx.map(v=>Math.pow(v-meanB,2)).reduce((s,v)=>s+v,0));
    return den===0?0:num/den;
  }
  const corrs = pairs.map(([x,y])=>({ pair: `${x}↔${y}`, r: corr(x,y) }));

  const tips = [
    'High comprehension, focus, and retention align with higher scores.',
    'Attention correlates with performance but slightly less than comprehension/focus.',
    'Engagement time helps, but returns diminish after ~90 minutes/day.',
    'Consider targeted interventions for low-engagement students.'
  ];

  return (
    <div>
      <ul>
        {corrs.map(c => <li key={c.pair}><strong>{c.pair}</strong>: r={c.r.toFixed(2)}</li>)}
      </ul>
      <ul>
        {tips.map((t,i)=><li key={i}>{t}</li>)}
      </ul>
    </div>
  );
}
