export function StatsCards({ stats }:{ stats: any }){
  const fmt = (n:number)=> n.toFixed(1);
  const card = (label:string, value:string)=> (
    <div style={{ background:'#0f1430', padding:16, borderRadius:12, border:'1px solid #263066' }}>
      <div style={{ opacity:0.7, fontSize:12 }}>{label}</div>
      <div style={{ fontSize:20, fontWeight:700, marginTop:6 }}>{value}</div>
    </div>
  );
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(6, 1fr)', gap:12, marginTop: 16 }}>
      {card('Avg Score', fmt(stats.avgScore))}
      {card('Avg Comp', fmt(stats.avgComp))}
      {card('Avg Attn', fmt(stats.avgAttn))}
      {card('Avg Focus', fmt(stats.avgFocus))}
      {card('Avg Retn', fmt(stats.avgRetn))}
      {card('Avg Eng (min)', fmt(stats.avgEng))}
    </div>
  );
}
