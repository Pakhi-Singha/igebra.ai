export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: 'Inter, system-ui, Arial', margin: 0, background: '#0b1020', color: 'white' }}>
        {children}
      </body>
    </html>
  );
}
