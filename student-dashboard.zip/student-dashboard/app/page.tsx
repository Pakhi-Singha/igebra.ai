'use client';

import { useMemo, useState } from 'react';
import students from '../public/students.json';
import { StatsCards } from '../components/StatsCards';
import { BarSkillVsScore } from '../components/BarSkillVsScore';
import { ScatterAttentionVsScore } from '../components/ScatterAttentionVsScore';
import { RadarStudentProfile } from '../components/RadarStudentProfile';
import { StudentTable } from '../components/StudentTable';
import { Insights } from '../components/Insights';

type Student = {
  student_id: string;
  name: string;
  class: string;
  comprehension: number;
  attention: number;
  focus: number;
  retention: number;
  assessment_score: number;
  engagement_time: number;
  persona_name?: string;
};

const SKILLS = ['comprehension','attention','focus','retention'] as const;

export default function Page() {
  const data = students as Student[];
  const [selectedSkill, setSelectedSkill] = useState<(typeof SKILLS)[number]>('comprehension');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(data[0]);

  const stats = useMemo(() => {
    const avg = (key: keyof Student) => data.reduce((s, r) => s + (r[key] as number), 0) / data.length;
    return {
      avgScore: avg('assessment_score'),
      avgComp: avg('comprehension'),
      avgAttn: avg('attention'),
      avgFocus: avg('focus'),
      avgRetn: avg('retention'),
      avgEng: avg('engagement_time'),
    };
  }, [data]);

  return (
    <main style={{ padding: 24, maxWidth: 1200, margin: '0 auto' }}>
      <h1 style={{ margin: 0, fontSize: 28, fontWeight: 700 }}>Student Learning Dashboard</h1>
      <p style={{ opacity: 0.8, marginTop: 4 }}>Overview • Correlations • Personas</p>

      <StatsCards stats={stats} />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 16 }}>
        <div style={{ background: '#121836', borderRadius: 12, padding: 16 }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <h3 style={{ margin: 0 }}>Skill vs Assessment Score</h3>
            <select value={selectedSkill} onChange={(e)=>setSelectedSkill(e.target.value as any)}>
              {SKILLS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <BarSkillVsScore data={data} skill={selectedSkill} />
        </div>

        <div style={{ background: '#121836', borderRadius: 12, padding: 16 }}>
          <h3 style={{ margin: 0 }}>Attention vs Performance</h3>
          <ScatterAttentionVsScore data={data} />
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 16 }}>
        <div style={{ background: '#121836', borderRadius: 12, padding: 16 }}>
          <h3 style={{ margin: 0 }}>Student Profile (Radar)</h3>
          <RadarStudentProfile student={selectedStudent || data[0]} />
          <p style={{ fontSize: 12, opacity: 0.8 }}>Click a student in the table to update the radar.</p>
        </div>
        <div style={{ background: '#121836', borderRadius: 12, padding: 16 }}>
          <h3 style={{ margin: 0 }}>Insights</h3>
          <Insights data={data} />
        </div>
      </div>

      <div style={{ background: '#121836', borderRadius: 12, padding: 16, marginTop: 16 }}>
        <h3 style={{ margin: 0 }}>Students</h3>
        <StudentTable data={data} onSelect={setSelectedStudent} />
      </div>
    </main>
  );
}
